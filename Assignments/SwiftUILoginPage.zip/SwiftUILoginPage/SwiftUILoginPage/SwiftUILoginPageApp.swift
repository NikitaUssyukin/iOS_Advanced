//
//  SwiftUILoginPageApp.swift
//  SwiftUILoginPage
//
//  Created by Yakuza on 16/09/2021.
//

import SwiftUI

@main
struct SwiftUILoginPageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
